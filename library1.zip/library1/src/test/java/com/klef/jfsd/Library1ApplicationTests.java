package com.klef.jfsd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Library1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
